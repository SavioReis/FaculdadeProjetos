#ifndef ARVORE_BINARIA_H
#define ARVORE_BINARIA_H

#include <iostream>
#include <string>

namespace ED1 {
class Pessoa {
public:
    int matricula;
    std::string nome;

    Pessoa(int matricula, const std::string& nome) : matricula(matricula), nome(nome) {}
};

class No {
public:
    Pessoa pessoa;
    No* esquerda;
    No* direita;

    No(int elemento) : pessoa(elemento, ""), esquerda(nullptr), direita(nullptr) {}
    No(Pessoa pessoa) : pessoa(pessoa), esquerda(nullptr), direita(nullptr) {}
};

class ArvoreBinaria {
private:
    No* raiz;

    void inserirRecursivo(No*& no, Pessoa pessoa);
    bool buscarRecursivo(No* no, int matricula, Pessoa& pessoaEncontrada);

public:
    ArvoreBinaria();
    ~ArvoreBinaria();

    void inserirPessoa(int matricula, const std::string& nome);
    bool buscarPessoa(int matricula, Pessoa& pessoaEncontrada);
};
}

#endif  // ARVORE_BINARIA_H
