#include "ArvoreBinaria.h"

int main() {
    ED1::ArvoreBinaria arvore;

    // Exemplo de inserção de pessoas na árvore
    arvore.inserirPessoa(1001, "João");
    arvore.inserirPessoa(1005, "Maria");
    arvore.inserirPessoa(1003, "Pedro");
    arvore.inserirPessoa(1002, "Ana");

    // Exemplo de busca de pessoa na árvore
    ED1::Pessoa pessoaEncontrada(0, "");
    if (arvore.buscarPessoa(1002, pessoaEncontrada)) {
        std::cout << "Pessoa encontrada: Matrícula: " << pessoaEncontrada.matricula << ", Nome: " << pessoaEncontrada.nome << std::endl;
    } else {
        std::cout << "Pessoa não encontrada!" << std::endl;
    }

    return 0;
}
